//   const serverURL = "https://webscraperbackend.hayden.co.in/";
const serverURL = "http://localhost:8080/";

  
export {serverURL}