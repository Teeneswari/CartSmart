package in.co.hayden.WebScraper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebScraperTests {

	@Test
	void contextLoads() {
	}

}
